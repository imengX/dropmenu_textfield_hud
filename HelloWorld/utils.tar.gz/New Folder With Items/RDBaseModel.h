//
//  RDBaseModel.h
//  RDCOCToken
//
//  Created by XenonChau on 27/07/2017.
//  Copyright © 2017 Co-In Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RDBaseModel : NSObject

@property (copy, nonatomic) NSString *code;
@property (copy, nonatomic) NSString *msg;
@property (copy, nonatomic) NSString *status;
@property (copy, nonatomic) NSString *token; //登录注册时会有此字段，其他请求不会。
@property (copy, nonatomic) id data; // 每个子类不同。

@end
