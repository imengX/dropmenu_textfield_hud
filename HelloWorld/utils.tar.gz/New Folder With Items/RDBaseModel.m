//
//  RDBaseModel.m
//  RDCOCToken
//
//  Created by XenonChau on 27/07/2017.
//  Copyright © 2017 Co-In Co.,Ltd. All rights reserved.
//

#import "RDBaseModel.h"

@implementation RDBaseModel



@end
