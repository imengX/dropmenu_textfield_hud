//
//  RDNetworkHelper.m
//  RDCOCToken
//
//  Created by XenonChau on 26/07/2017.
//  Copyright © 2017 Co-In Co.,Ltd. All rights reserved.
//

#import "RDNetworkHelper.h"
#import "RDUtils.h"

@implementation RDNetworkHelper

+ (NSDictionary *)addSignature:(NSDictionary *)originParams {
    // 给参数字典增加签名字段。
    NSMutableDictionary *newDict = [originParams mutableCopy];
    
    NSArray *sortedKeys = [originParams.allKeys sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2){
        return [obj1 compare:obj2 options:NSNumericSearch];
    }];
    
    
    NSString *dictString = @"";
    for (int i = 0; i < sortedKeys.count; i++) {
        NSString *key = sortedKeys[i];
        NSString *value = originParams[key];
        NSString *key_value = @"";
        if (i) {
            key_value = [NSString stringWithFormat:@"&%@=%@", key, value];
        } else {
            key_value = [NSString stringWithFormat:@"%@=%@", key, value];
        }
        
        dictString = [dictString stringByAppendingString:key_value];
    }
    
    NSString *md5_double_encrypt = [[dictString MD5Digest] MD5Digest];
    
    newDict[@"sig"] = md5_double_encrypt;
    
    return [newDict copy];
}

@end
