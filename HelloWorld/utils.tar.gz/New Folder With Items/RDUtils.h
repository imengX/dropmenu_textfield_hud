//
//  RDUtils.h
//  RDCOCToken
//
//  Created by XenonChau on 25/07/2017.
//  Copyright © 2017 Co-In Co.,Ltd. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "RDLoginModel.h"
#import "Enum.h"

@interface RDUtils : NSObject

+ (__kindof UIViewController *)applicationRootViewController;

@end

@interface UserInfo : NSObject
/*!
 @remarks 不要跟我讲什么“啊凯乌”了、什么“分泌大便”！拿 “男士用户缺省” 就是干！
 */
+ (void)storageUserInfo:(RDLoginModel *)model;
#pragma mark - 用户 Token
+ (void)userToken:(NSString *)token;
+ (NSString *)userToken;
#pragma mark - 用户名
+ (void)username:(NSString *)username;
+ (NSString *)username;
#pragma mark - 用户id
+ (void)uID:(NSString *)userID;
+ (NSString *)uID;
#pragma mark - 用户邀请码
+ (void)inviteCode:(NSString *)inviteCode;
+ (NSString *)inviteCode;
#pragma mark - Addresses
+ (void)addressBTC:(NSString *)btc_address;
+ (NSString *)addressBTC;
+ (void)addressCOC:(NSString *)coc_address;
+ (NSString *)addressCOC;
+ (void)addressETC:(NSString *)etc_address;
+ (NSString *)addressETC;
+ (void)addressETH:(NSString *)eth_address;
+ (NSString *)addressETH;
+ (void)addressZEC:(NSString *)zec_address;
+ (NSString *)addressZEC;

@end

@interface NSString (MD5)

- (NSString *)MD5Digest;

@end



@interface NSString (UnitExchange)
+ (NSString *)transferDateByDay:(NSString *)intervalSince1970;
+ (NSString *)transferDateByMinute:(NSString *)intervalSince1970;
+ (NSString *)timerIntervalSincePastDate:(NSString *)intervalSince1970;
+ (NSString *)timerIntervalSincePastDate_2:(NSString *)intervalSince1970;
+ (NSString *)spiteDate:(NSString *)intervalSince1970 withType:(DateType)type;

- (NSString *)bc_stringTypeCurrency;
- (NSString *)bc_stringTypeCurrencyFloor;

@end


static NSString *notificationLoadDeposit = @"notificationLoadDeposit";
static NSString *notificationLoadWithdraw = @"notificationLoadWithdraw";

@interface RDGlobal : NSObject

+ (instancetype)global;
/**
 把LoginModel放在一个全局的单例里，自然是解耦合的一种手段。但是当用户退出后台，单例被销毁。再次加载会导致闪退。所以还需要一个刷新逻辑。
 暂时就这样放着吧，我觉得可能到时候又要大改。。。
 */
@property (strong, nonatomic) RDLoginModel *loginModel;
@property (copy, nonatomic) NSArray *currencies;
+ (UIWindow *)keyWindow;

@end

