static NSString *kUserToken = @"usertoken";
static NSString *kUsername = @"username";
static NSString *kUserID = @"uid";
static NSString *kUserInfo = @"userInfo";
static NSString *kInviteCode = @"inviteCode";

static NSString *kAddressBTC = @"btc_address";
static NSString *kAddressCOC = @"coc_address";
static NSString *kAddressETC = @"etc_address";
static NSString *kAddressETH = @"eth_address";
static NSString *kAddressZEC = @"zec_address";

#import "RDUtils.h"
#import "AppDelegate.h"

@implementation RDUtils

+ (__kindof UIViewController *)applicationRootViewController {
    UIApplication *app = [UIApplication sharedApplication];
    AppDelegate *delegate = (AppDelegate *)app.delegate;
    UIWindow *keyWindow = delegate.window;
    return keyWindow.rootViewController;
}

@end

@implementation UserInfo

+ (NSUserDefaults *)info {
    return [NSUserDefaults standardUserDefaults];
}

+ (void)storage:(id)obj key:(NSString *)key {
    [[NSUserDefaults standardUserDefaults] setObject:obj forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (void)storageUserInfo:(RDLoginModel *)model {
    
    /**
     @property btc_address;
     @property coc_address;
     @property etc_address;
     @property eth_address;
     @property zec_address;
     @property invite_code;
     @property username;
     @property uid;
     // 下面是无需保存的。
     @property create_time;
     @property platform;
     @property pre_ico_asset;
     @property btc_asset;
     @property coc_asset;
     @property etc_asset;
     @property eth_asset;
     @property zec_asset;
     */
    [self storage:model.btc_address key:kAddressBTC];
    [self storage:model.coc_address key:kAddressCOC];
    [self storage:model.etc_address key:kAddressETC];
    [self storage:model.eth_address key:kAddressETH];
    [self storage:model.zec_address key:kAddressZEC];
    [self storage:model.invite_code key:kInviteCode];
    [self storage:model.username key:kUsername];
    [self storage:model.uid key:kUserID];
    
}

#pragma mark - 用户 Token
+ (void)userToken:(NSString *)token {
    [self storage:token key:kUserToken];
    
}
+ (NSString *)userToken {
    return [[self info] objectForKey:kUserToken];
}
#pragma mark - 用户名
+ (void)username:(NSString *)username {
    [self storage:username key:kUsername];
}
+ (NSString *)username {
    return [[self info] objectForKey:kUsername];
}
#pragma mark - 用户id
+ (void)uID:(NSString *)userID {
    [self storage:userID key:kUserID];
}
+ (NSString *)uID {
    return [[self info] objectForKey:kUserID];
}
#pragma mark - 用户邀请码
+ (void)inviteCode:(NSString *)inviteCode {
    [self storage:inviteCode key:kInviteCode];
}
+ (NSString *)inviteCode {
    return [[self info] objectForKey:kInviteCode];
}

#pragma mark - Addresses
+ (void)addressBTC:(NSString *)btc_address {
    [self storage:btc_address key:kAddressBTC];
}
+ (NSString *)addressBTC {
    return [[self info] objectForKey:kAddressBTC];
}
+ (void)addressCOC:(NSString *)coc_address {
    [self storage:coc_address key:kAddressCOC];
}
+ (NSString *)addressCOC {
    return [[self info] objectForKey:kAddressCOC];
}
+ (void)addressETC:(NSString *)etc_address {
    [self storage:etc_address key:kAddressETC];
}
+ (NSString *)addressETC {
    return [[self info] objectForKey:kAddressETC];
}
+ (void)addressETH:(NSString *)eth_address {
    [self storage:eth_address key:kAddressETH];
}
+ (NSString *)addressETH {
    return [[self info] objectForKey:kAddressETH];
}
+ (void)addressZEC:(NSString *)zec_address {
    [self storage:zec_address key:kAddressZEC];
}
+ (NSString *)addressZEC {
    return [[self info] objectForKey:kAddressZEC];
}


@end

#import <CommonCrypto/CommonDigest.h>
@implementation NSString (MD5)

- (NSString *)MD5Digest
{
    const char* input = [self UTF8String];
    unsigned char result[CC_MD5_DIGEST_LENGTH];
    CC_MD5(input, (CC_LONG)strlen(input), result);
    
    NSMutableString *digest = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH * 2];
    for (NSInteger i = 0; i < CC_MD5_DIGEST_LENGTH; i++) {
        [digest appendFormat:@"%02x", result[i]];
    }
    
    return digest;
}

@end


@implementation NSString (UnitExchange)

+ (NSString *)timerIntervalSincePastDate:(NSString *)intervalSince1970 {
    NSDate *currentDate = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    
    NSString *currentDateString = [formatter stringFromDate:currentDate];
    
    NSDate *sinceDate = [NSDate dateWithTimeIntervalSince1970:intervalSince1970.doubleValue / 1e3];
    NSString *sinceDateString = [formatter stringFromDate:sinceDate];
    // NSDate *actionDate = [formatter dateFromString:sinceDateString];
    
    if (sinceDateString.length < formatter.dateFormat.length) {
        return @"未知时间";
    }
    
    NSString *currentYear = [currentDateString substringToIndex:4];
    NSString *actionYear = [sinceDateString substringToIndex:4];
    
    NSString *currentMonth = [currentDateString substringWithRange:NSMakeRange(5, 2)];
    NSString *actionMonth = [sinceDateString substringWithRange:NSMakeRange(5, 2)];
    
    NSString *currentDay = [currentDateString substringWithRange:NSMakeRange(8, 2)];
    NSString *actionDay = [sinceDateString substringWithRange:NSMakeRange(8, 2)];
    
    NSString *currentHour = [currentDateString substringWithRange:NSMakeRange(11, 2)];
    NSString *actionHour = [sinceDateString substringWithRange:NSMakeRange(11, 2)];
    
    NSString *currentMinute = [currentDateString substringWithRange:NSMakeRange(14, 2)];
    NSString *actionMinute = [sinceDateString substringWithRange:NSMakeRange(14, 2)];
    
    NSString *currentSecond = [currentDateString substringWithRange:NSMakeRange(17, 2)];
    NSString *actionSecond = [sinceDateString substringWithRange:NSMakeRange(17, 2)];
    
    
    if (![currentYear isEqualToString:actionYear]) {
        return [NSString stringWithFormat:@"%@年前", @(currentYear.integerValue - actionYear.integerValue).stringValue];
    }
    
    if (![currentMonth isEqualToString:actionMonth]) {
        return [NSString stringWithFormat:@"%@月前", @(currentMonth.integerValue - actionMonth.integerValue).stringValue];
    }
    
    if (![currentDay isEqualToString:actionDay]) {
        return [NSString stringWithFormat:@"%@天前", @(currentDay.integerValue - actionDay.integerValue).stringValue];
    }
    
    if (![currentHour isEqualToString:actionHour]) {
        return [NSString stringWithFormat:@"%@小时前", @(currentHour.integerValue - actionHour.integerValue).stringValue];
    }
    
    if (![currentMinute isEqualToString:actionMinute]) {
        return [NSString stringWithFormat:@"%@分钟前", @(currentMinute.integerValue - actionMinute.integerValue).stringValue];
    }
    
    if (currentSecond.doubleValue <= actionSecond.doubleValue) {
        return @"刚刚";
        //return [NSString stringWithFormat:@"%@秒前", @(currentSecond.integerValue - actionSecond.integerValue).stringValue];
    }
    return @"刚刚";
}

+ (NSString *)transferDateByDay:(NSString *)intervalSince1970 {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd";
    NSDate *sinceDate = [NSDate dateWithTimeIntervalSince1970:intervalSince1970.doubleValue / 1e3];
    NSString *sinceDateString = [formatter stringFromDate:sinceDate];
    return sinceDateString;
}

+ (NSString *)transferDateByMinute:(NSString *)intervalSince1970 {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"HH:mm";
    NSDate *sinceDate = [NSDate dateWithTimeIntervalSince1970:intervalSince1970.doubleValue / 1e3];
    NSString *sinceDateString = [formatter stringFromDate:sinceDate];
    return sinceDateString;
}

+ (NSString *)timerIntervalSincePastDate_2:(NSString *)intervalSince1970 {
    NSDate *currentDate = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    
    NSString *currentDateString = [formatter stringFromDate:currentDate];
    
    NSDate *sinceDate = [NSDate dateWithTimeIntervalSince1970:intervalSince1970.doubleValue / 1e3];
    NSString *sinceDateString = [formatter stringFromDate:sinceDate];
    // NSDate *actionDate = [formatter dateFromString:sinceDateString];
    
    if (sinceDateString.length < formatter.dateFormat.length) {
        return @"未知时间";
    }
    
    NSString *currentYear = [currentDateString substringToIndex:4];
    NSString *actionYear = [sinceDateString substringToIndex:4];
    
    NSString *currentMonth = [currentDateString substringWithRange:NSMakeRange(5, 2)];
    NSString *actionMonth = [sinceDateString substringWithRange:NSMakeRange(5, 2)];
    
    NSString *currentDay = [currentDateString substringWithRange:NSMakeRange(8, 2)];
    NSString *actionDay = [sinceDateString substringWithRange:NSMakeRange(8, 2)];
    
    BOOL sameYear = [currentYear isEqualToString:actionYear];
    BOOL sameMonth = [currentMonth isEqualToString:actionMonth];
    
    if (sameYear && sameMonth) {
        NSInteger dayInterval = currentDay.integerValue - actionDay.integerValue;
        if (dayInterval > 1 && dayInterval < 4) {
            return [NSString stringWithFormat:@"%@天前", @(currentDay.integerValue - actionDay.integerValue).stringValue];
        }
        if (dayInterval == 1) {
            return @"昨天";
        }
        if (!dayInterval) {
            return @"今天";
        }
    }
    
    
    return sinceDateString;
}

+ (NSString *)spiteDate:(NSString *)intervalSince1970 withType:(DateType)type {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    
    NSDate *sinceDate = [NSDate dateWithTimeIntervalSince1970:intervalSince1970.doubleValue / 1e3];
    NSString *sinceDateString = [formatter stringFromDate:sinceDate];
    
    if (sinceDateString.length < formatter.dateFormat.length) {
        return @"未知时间";
    }
    
    NSString *actionYear = [sinceDateString substringToIndex:4];
    NSString *actionDate = [sinceDateString substringWithRange:NSMakeRange(5, 5)];
    NSString *actionTime = [sinceDateString substringWithRange:NSMakeRange(11, 5)];
    switch (type) {
        case Year: {
            return actionYear;
            break;
        }
        case Date: {
            return actionDate;
            break;
        }
        case Time: {
            return actionTime;
            break;
        }
        default: {
            return @"未知时间";
            break;
        }
    }
    
}

- (NSString *)bc_stringTypeCurrency {
    NSString *selfValue = self;
    if (selfValue.doubleValue >= 1e9) {
        selfValue = [NSString stringWithFormat:@"%.2fb", floor(self.doubleValue / 1e7) / 100];
        return selfValue;
    }
    if (selfValue.doubleValue >= 1e6) {
        selfValue = [NSString stringWithFormat:@"%.2fm", floor(self.floatValue / 1e4) / 100];
        return selfValue;
    }
    return selfValue;
}

- (NSString *)bc_stringTypeCurrencyFloor {
    NSString *selfValue = self;
    if (selfValue.doubleValue >= 1e9) {
        selfValue = [NSString stringWithFormat:@"%1.fb", floor(self.doubleValue / 1e9)];
        return selfValue;
    }
    if (selfValue.doubleValue >= 1e6) {
        selfValue = [NSString stringWithFormat:@"%1.fm", floor(self.floatValue / 1e4)];
        return selfValue;
    }
    if (selfValue.doubleValue >= 1e3) {
        selfValue = [NSString stringWithFormat:@"%1.fk", floor(self.floatValue / 1e3)];
        return selfValue;
    }
    if (selfValue.doubleValue >= 10) {
        selfValue = [NSString stringWithFormat:@"%1.f", floor(self.floatValue)];
        return selfValue;
    }
    return selfValue;
}

@end


@implementation RDGlobal

static RDGlobal * kSingleton = nil;

+ (instancetype)global {
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        kSingleton = [[self alloc] init];
    });
    
    return kSingleton;
}

- (instancetype)init {
    if (self = [super init]) {
        _currencies = @[@"COC", @"BTC", @"ETC", @"ETH", @"ZEC"];
    }
    return self;
}

+ (UIWindow *)keyWindow {
    // Default case: iterate over UIApplication windows
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow]; // as default.
    NSEnumerator *frontToBackWindows = [UIApplication.sharedApplication.windows reverseObjectEnumerator];
    for (UIWindow *window in frontToBackWindows) {
        BOOL windowOnMainScreen = window.screen == UIScreen.mainScreen;
        BOOL windowIsVisible = !window.hidden && window.alpha > 0;
        BOOL windowLevelNormal = window.windowLevel == UIWindowLevelNormal;
        
        if(windowOnMainScreen && windowIsVisible && windowLevelNormal) {
            keyWindow = window;
            break;
        }
    }
    return keyWindow;
}

@end



