//
//  ViewController.m
//  HelloWorld
//
//  Created by XenonChau on 22/08/2017.
//  Copyright © 2017 Code1Bit Co.,Ltd. All rights reserved.
//

#import "ViewController.h"
#import "Masonry.h"
#import "HexColors.h"
#import "ReactiveCocoa.h"

#import "XCDropMenu.h"
#import "XCTextField.h"
#import "XCHUDView.h"

@interface ViewController ()

@end
UIColor *bgColor;
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    bgColor = [UIColor hx_colorWithHexRGBAString:@"#38265E"];
    self.view.backgroundColor = bgColor;
    
    NSArray *dddaaatttaaa = @[@"BTC", @"ETC", @"COC", @"ZEC", @"林更新", @"薛之谦", @"马云", @"刘洋"];
    XCDropMenu *dropMenu1 = [[XCDropMenu alloc] initWithFrame:CGRectZero];
    [self.view addSubview:dropMenu1];
    [dropMenu1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.leading.equalTo(self.view).offset(20);
        make.height.mas_equalTo(50);
        make.width.mas_equalTo(165);
    }];
    dropMenu1.dataSource = dddaaatttaaa;
    dropMenu1.itemSelectCallback = ^(NSInteger index) {
        NSLog(@"%@", dddaaatttaaa[index]);
    };
    XCDropMenu *dropMenu = [[XCDropMenu alloc] initWithFrame:CGRectZero];
    [self.view addSubview:dropMenu];
    [dropMenu mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(dropMenu1.mas_bottom).offset(20);
        make.leading.equalTo(self.view).offset(20);
        make.height.mas_equalTo(50);
        make.width.mas_equalTo(165);
    }];
    dropMenu.dataSource = dddaaatttaaa;
    dropMenu.itemSelectCallback = ^(NSInteger index) {
        NSLog(@"%@", dddaaatttaaa[index]);
    };
    
    XCTextField *textField = [[XCTextField alloc] init];
    textField.placeholder = @"请输入你姥姥的名字";
    [self.view addSubview:textField];
    [textField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(dropMenu1.mas_trailing).offset(10);
        make.centerY.height.equalTo(dropMenu1);
        make.trailing.equalTo(self.view).offset(-20);
    }];
    
    XCHUDView *hud = [[XCHUDView alloc] init];
    hud.position = XCHUDPositionCenter;
    hud.style = XCHUDMessage;
    hud.animations = XCHUDAnimationStyleFallInAndOut;
    [self.view addSubview:hud];
    [hud mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.top.bottom.equalTo(self.view);
    }];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
