//
//  XCDropMenu.m
//  HelloWorld
//
//  Created by XenonChau on 22/08/2017.
//  Copyright © 2017 Code1Bit Co.,Ltd. All rights reserved.
//

#import "XCDropMenu.h"
#import "HexColors.h"
#import "Masonry.h"

@interface XCDropMenu () <UITableViewDelegate, UITableViewDataSource>

@property (strong, nonatomic) UIView *menuView;
@property (strong, nonatomic) UITableView *tableView;

@end

@implementation XCDropMenu

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initialValues];
        [self initialViews];
    }
    return self;
}

- (UIView *)menuView {
    if (!_menuView) {
        CGPoint origin = self.frame.origin;
        _menuView = [[UIView alloc] initWithFrame:
                     (CGRect){
                         origin.x,
                         origin.y + self.frame.size.height + 5,
                         self.frame.size.width,
                         self.itemHeight * self.numberOfShownItems
                     }];
        _menuView.alpha = 0;
        _menuView.layer.masksToBounds = YES;
        _menuView.layer.cornerRadius = 2;
        _menuView.layer.borderWidth = 0.5;
        _menuView.layer.borderColor = self.borderColor.CGColor;
        _menuView.backgroundColor = self.backgroundColor;
    }
    return _menuView;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:
                      (CGRect){
                          0,
                          0,
                          self.menuView.frame.size.width,
                          self.menuView.frame.size.height
                      }
                      
                                                  style:UITableViewStylePlain];
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [UIView new];
        _tableView.layer.cornerRadius = 2;
        _tableView.layer.masksToBounds = YES;
        _tableView.layer.borderColor = self.borderColor.CGColor;
        _tableView.layer.borderWidth = 0.5;
        _tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
        _tableView.separatorColor = self.borderColor;
        _tableView.alpha = 0;
        
    }
    return _tableView;
}

- (void)initialValues {
    self.backgroundColor = [UIColor colorWithRed:56.f/255.f green:38.f/255.f blue:94.f/255.f alpha:1];
    self.borderColor = [UIColor colorWithRed:128.f/255.f green:138.f/255.f blue:172.f/255.f alpha:1];
    self.itemHeight = 50;
    self.numberOfShownItems = 4;
    self.dataSource = @[];
    self.hideMenuAfterTouch = YES;
}

- (void)initialViews {
    
    self.borderColor = [UIColor hx_colorWithHexRGBAString:@"808AAC"];
    self.textColor = [UIColor whiteColor];
    self.layer.cornerRadius = 2;
    self.layer.borderColor = self.borderColor.CGColor;
    self.layer.borderWidth = 0.5;
    [self addTarget:self action:@selector(controlAction:) forControlEvents:UIControlEventTouchUpInside];
    
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    if (!self.menuView.superview) {
        [self.superview addSubview:self.menuView];
    }
    
    if (!self.tableView.superview) {
        [self.menuView addSubview:self.tableView];
    }
    
    if (!self.iconView) {
        self.iconView = [[UIImageView alloc] initWithFrame:(CGRect){0, 0, self.frame.size.height * 0.8, self.frame.size.height * 0.8}];
        self.iconView.image = [UIImage imageNamed:@""];
        [self addSubview:self.iconView];
    }
    
    if (!self.titleLabel) {
        self.titleLabel = [[UILabel alloc] initWithFrame:(CGRect){self.frame.size.width / 4, 0, self.frame.size.width / 2, self.frame.size.height}];
        self.titleLabel.text = @"ETH";
        self.titleLabel.textColor = self.textColor;
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.titleLabel];
    }
    
    
}

- (void)controlAction:(UIControl *)control {
    
    self.selected = !self.selected;
    
    if (self.selected) {
        [self showMenuAnimated:YES];
    } else {
        [self hideMenuAnimated:YES];
    }
}

#pragma mark - TableView Delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return self.itemHeight;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    // 外部传入 reuseIdentifier, Class？
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.textLabel.text = self.dataSource[indexPath.row];
    cell.contentView.backgroundColor = [UIColor clearColor];
    cell.backgroundColor = [UIColor clearColor];
    cell.textLabel.textColor = self.textColor;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    self.titleLabel.text = self.dataSource[indexPath.row];
    !_itemSelectCallback ? : _itemSelectCallback(indexPath.row);
    if (self.hideMenuAfterTouch) {
        [self hideMenuOutside];
    }
}

#pragma mark - hitTest

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    if (!self.isUserInteractionEnabled || self.isHidden || self.alpha <= 0.01) {
        return nil;
    }
    CGPoint menuTouchPoint = CGPointMake(point.x,
                                         point.y - self.frame.size.height - 5);
    
    if ([self pointInside:point withEvent:event]) {
        return self;
    } else if ([self.menuView pointInside:menuTouchPoint withEvent:event]) {
        return [self.menuView hitTest:menuTouchPoint withEvent:event];
    } else {
        [self hideMenuOutside];
    }
    return nil;
}

#pragma mark - Menu Animation

- (void)showMenuAnimated:(BOOL)animate {
    if (self.numberOfShownItems >= self.dataSource.count) {
        self.numberOfShownItems = self.dataSource.count;
        self.tableView.scrollEnabled = NO;
    } else {
        self.tableView.scrollEnabled = YES;
    }
    [self.superview bringSubviewToFront:self.menuView];
    [UIView animateWithDuration:animate ? 0.25f : 0.0f animations:^{
        self.menuView.alpha = 1;
        self.tableView.alpha = 1;
        self.menuView.frame = (CGRect){
                                         self.frame.origin.x,
                                         self.frame.origin.y + self.frame.size.height + 5,
                                         self.menuView.frame.size.width,
                                         self.itemHeight * self.numberOfShownItems
                                        };
        [self.menuView layoutSubviews];
    }];
}

- (void)hideMenuAnimated:(BOOL)animate {
    if (self.numberOfShownItems >= self.dataSource.count) {
        self.numberOfShownItems = self.dataSource.count;
        self.tableView.scrollEnabled = NO;
    } else {
        self.tableView.scrollEnabled = YES;
    }
    [self.superview sendSubviewToBack:self.menuView];
    [UIView animateWithDuration:animate ? 0.25f : 0.0f animations:^{
        self.menuView.alpha = 0;
        self.tableView.alpha = 0;
        self.menuView.frame = (CGRect){
                                         self.frame.origin.x,
                                         self.frame.origin.y + self.frame.size.height + 5,
                                         self.menuView.frame.size.width,
                                         0
                                        };
        [self.menuView layoutSubviews];
    }];
}

- (void)hideMenuOutside {
    self.selected = NO;
    [self hideMenuAnimated:YES];
}


@end
