//
//  XCHUDView.m
//  HelloWorld
//
//  Created by XenonChau on 24/08/2017.
//  Copyright © 2017 Code1Bit Co.,Ltd. All rights reserved.
//

#import "XCHUDView.h"

@implementation XCHUDView

- (void)layoutSubviews {
    [super layoutSubviews];
    switch (self.position) {
        case XCHUDPositionCenter: {
            [self centerLayout];
            break;
        }
        case XCHUDPositionTop: {
            
            break;
        }
        case XCHUDPositionBottom: {
            
            break;
        }
        default:
            break;
    }
    
}

- (void)centerLayout {
    switch (self.style) {
        case XCHUDMessage: {
            
            break;
        }
        case XCHUDLoading: {
            
            break;
        }
        case XCHUDSuccess: {
            
            break;
        }
        case XCHUDFailed: {
            
            break;
        }
        default: {
            NSLog(@"不支持的样式");
            break;
        }
    }
    
    
    UIView *bgView = [[UIView alloc] initWithFrame:CGRectZero];
    bgView.backgroundColor = [UIColor whiteColor];
    bgView.tag = 890;
    [self addSubview:bgView];
    
    self.titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    self.titleLabel.text = @"1233";
    [self addSubview:self.titleLabel];
    
    
    NSLayoutConstraint * bg_leading = [self constraintFrom:bgView attribute:NSLayoutAttributeLeading equalTo:self offset:20];
    NSLayoutConstraint * bg_trailing = [self constraintFrom:bgView attribute:NSLayoutAttributeTrailing equalTo:self offset:20];
    NSLayoutConstraint * bg_center_y = [self constraintFrom:bgView attribute:NSLayoutAttributeCenterY equalTo:self];
    NSLayoutConstraint * bg_height = [self constraintFrom:bgView attribute:NSLayoutAttributeHeight equal:210];
    bg_height.priority = UILayoutPriorityDefaultHigh;
    
    NSLayoutConstraint * title_leading = [self constraintFrom:self.titleLabel attribute:NSLayoutAttributeLeading equalTo:bgView ];
    NSLayoutConstraint * title_trailing = [self constraintFrom:self.titleLabel attribute:NSLayoutAttributeTrailing equalTo:bgView];
    NSLayoutConstraint * title_top = [self constraintFrom:self.titleLabel attribute:NSLayoutAttributeTop equalTo:bgView offset:20];
    NSLayoutConstraint * title_height = [self constraintFrom:self.titleLabel attribute:NSLayoutAttributeHeight equal:50];
    title_height.priority = UILayoutPriorityDefaultHigh;
    
    [NSLayoutConstraint activateConstraints:@[bg_leading, bg_trailing, bg_center_y, bg_height]];
    [NSLayoutConstraint activateConstraints:@[title_leading, title_trailing, title_top, title_height]];
    
}

- (NSLayoutConstraint *)constraintFrom:(UIView *)first
                             attribute:(NSLayoutAttribute)attr0
                               equalTo:(UIView *)second
                             attribute:(NSLayoutAttribute)attr1
                                offset:(CGFloat)offset {
    return [NSLayoutConstraint constraintWithItem:first attribute:attr0 relatedBy:NSLayoutRelationEqual toItem:second attribute:attr1 multiplier:1 constant:offset];
}

- (NSLayoutConstraint *)constraintFrom:(UIView *)first
                             attribute:(NSLayoutAttribute)attr
                               equalTo:(UIView *)second
                                offset:(CGFloat)offset {
    return [NSLayoutConstraint constraintWithItem:first attribute:attr relatedBy:NSLayoutRelationEqual toItem:second attribute:attr multiplier:1 constant:offset];
}

- (NSLayoutConstraint *)constraintFrom:(UIView *)first
                             attribute:(NSLayoutAttribute)attr
                               equalTo:(UIView *)second {
    return [NSLayoutConstraint constraintWithItem:first attribute:attr relatedBy:NSLayoutRelationEqual toItem:second attribute:attr multiplier:1 constant:0];
}

- (NSLayoutConstraint *)constraintFrom:(UIView *)first
                             attribute:(NSLayoutAttribute)attr
                                 equal:(CGFloat)value {
    return [NSLayoutConstraint constraintWithItem:first attribute:attr relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:value];
}

- (void)topLayout {
    switch (self.style) {
        case XCHUDMessage: {
            
            break;
        }
        case XCHUDLoading: {
            
            break;
        }
        case XCHUDSuccess: {
            
            break;
        }
        case XCHUDFailed: {
            
            break;
        }
        case XCHUDStyleAlertView: {
            // 弹出对话框
            
            break;
        }
        default: {
            NSLog(@"不支持的样式");
            break;
        }
    }
    
    
    
    
}

- (void)bottomLayout {
    switch (self.style) {
        case XCHUDMessage: {
            
            break;
        }
        case XCHUDLoading: {
            
            break;
        }
        case XCHUDSuccess: {
            
            break;
        }
        case XCHUDFailed: {
            
            break;
        }
        case XCHUDStyleShareSheet: {
            // 分享样式
            
            break;
        }
        case XCHUDStyleActionSheet: {
            // 底部菜单栏
            
            break;
        }
        default: {
            NSLog(@"不支持的样式");
            break;
        }
    }
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    if (!self.isUserInteractionEnabled || self.isHidden || self.alpha <= 0.01) {
        return nil;
    }
    if (self.style == XCHUDStyleAlertView) {
        
    } else {
        if ([self pointInside:point withEvent:event]) {
            for (UIView *subview in [self.subviews reverseObjectEnumerator]) {
                CGPoint convertedPoint = [subview convertPoint:point fromView:self];
                UIView *hitTestView = [subview hitTest:convertedPoint withEvent:event];
                if (hitTestView) {
                    return hitTestView;
                }
            }
            [self hideHUD];
            return self;
        }
    }
    return nil;
}

- (void)willMoveToSuperview:(UIView *)newSuperview {
    [super willMoveToSuperview:newSuperview];
    [self fallInFromTop];
}

- (void)hideHUD {
    [self fallOutToBottom];
}


#pragma mark - Aminations

- (void)fallInFromTop {
    CGAffineTransform transform = CGAffineTransformIdentity;
    transform = CGAffineTransformTranslate(transform, 0, -524);
    [UIView animateWithDuration:0 animations:^{
        self.layer.affineTransform = transform;
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.5f animations:^{
            self.layer.affineTransform = CGAffineTransformMakeTranslation(0, 0);
        }];
    }];
}

- (void)fallOutToBottom {
    CGAffineTransform transform = CGAffineTransformIdentity;
    transform = CGAffineTransformTranslate(transform, 0, 1024);
    [UIView animateWithDuration:0.5f animations:^{
        self.layer.affineTransform = transform;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}


@end
